<?php
$lang['L_LOG_DELETE']="Eliminar fichero de historial (log)";
$lang['L_LOGFILEFORMAT']="Formato del fichero de historial (log)";
$lang['L_LOGFILENOTWRITABLE']="No se puede escribir en el fichero de historial (log)!";
$lang['L_NOREVERSE']="Mostrar las entradas más antiguas primero";
$lang['L_REVERSE']="Mostrar las entradas más nuevas primero";


?>