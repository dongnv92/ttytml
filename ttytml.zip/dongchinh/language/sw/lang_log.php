<?php
$lang['L_LOG_DELETE']="Radera loggen";
$lang['L_LOGFILEFORMAT']="Loggfilformat";
$lang['L_LOGFILENOTWRITABLE']="Loggfilen kan ej skrivas!";
$lang['L_NOREVERSE']="Äldsta posten först";
$lang['L_REVERSE']="Nyaste posten först";


?>