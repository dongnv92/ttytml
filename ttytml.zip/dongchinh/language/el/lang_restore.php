<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="μέχρι τώρα δημιουργήθηκαν <b>%d</b> πίνακες.";
$lang['L_FILE_MISSING']="δε βρέθηκε το αρχείο";
$lang['L_RESTORE_DB']="Β.Δεδομένων '<b>%s</b>' σε '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> πίνακες δημιουργήθηκαν.";
$lang['L_RESTORE_RUN1']="<br>Μέχρι τώρα  <b>%s</b> από <b>%s</b> εγγραφές έχουν προστεθεί.";
$lang['L_RESTORE_RUN2']="<br>Τώρα ο πίνακας '<b>%s</b>' επαναφέρεται.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> εγγραφές έχουν εισαχθεί.";
$lang['L_RESTORE_TABLES_COMPLETED']="Μέχρι τώρα <b>%d</b> από <b>%d</b> πίνακες δημιουργήθηκαν.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Συγχαρητήρια.</b><br><br>Εγινε η επαναφορά της Β.Δεδομένων.<br>Ολα τα δεδομένα απο το Αντίγραφο Ασφαλείας έχουν επαναφερθεί.<br><br>Ολα ολοκληρώθηκαν. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Σφάλμα:<br>Επιλογή Β.Δεδομένων <b>";
$lang['L_DB_SELECT_ERROR2']="</b> απέτυχε!";
$lang['L_FILE_OPEN_ERROR']="Σφάλμα: δεν μπόρεσα να ανοίξω το αρχείο.";
$lang['L_PROGRESS_OVER_ALL']="Γενική πρόοδος";
$lang['L_BACK_TO_OVERVIEW']="Προεπισκόπιση Β.Δεδομένων";
$lang['L_RESTORE_RUN0']="<br>Μέχρι τώρα <b>%s</b> εγγραφές έχουν προστεθεί.";
$lang['L_UNKNOWN_SQLCOMMAND']="Αγνωστη εντολή SQL";
$lang['L_NOTICES']="Σημειώσεις


";


?>