<?php
$lang['L_LOG_DELETE']="διαγραφή καταγραφής";
$lang['L_LOGFILEFORMAT']="μορφή αρχείου καταγραφής";
$lang['L_LOGFILENOTWRITABLE']="Δε μπορώ να γράψω σε αρχείο καταγραφής !";
$lang['L_NOREVERSE']="Πρώτα παλιές εγγραφές";
$lang['L_REVERSE']="Πρώτα τελευταίες εγγραφές

";


?>