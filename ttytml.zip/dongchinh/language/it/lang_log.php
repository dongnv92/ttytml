<?php
$lang['L_LOG_DELETE']="Cancella i log";
$lang['L_LOGFILEFORMAT']="Formato del file log";
$lang['L_LOGFILENOTWRITABLE']="Impossibile scrivere il file di log!";
$lang['L_NOREVERSE']="Il piu vecchio come primo";
$lang['L_REVERSE']="Il piu nuovo come primo";


?>